<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;
use PHPMailer\PHPMailer\SMTP;

require 'PHPMailer/Exception.php';
require 'PHPMailer/PHPMailer.php';
require 'PHPMailer/SMTP.php';

if (isset($_POST['nombre'])) {
    
    $nombre = htmlentities($_POST['nombre'], ENT_QUOTES);
    $ciudad  = htmlentities($_POST['lugar'], ENT_QUOTES);
    $telf   = htmlentities($_POST['celular'], ENT_QUOTES);
    $mensaje_usuario = htmlentities($_POST['consulta'], ENT_QUOTES);

    $mail = new PHPMailer(true);

    try {
        //Server settings
        // $mail->SMTPDebug = SMTP::DEBUG_SERVER;                      // Enable verbose debug output
        $mail->isSMTP();                                            // Send using SMTP
        $mail->Host       = 'mail.farmacias-cytotec-peru.shop';                  // Set the SMTP server to send through
        $mail->SMTPAuth   = true;                                   // Enable SMTP authentication
        $mail->Username   = 'envio@farmacias-cytotec-peru.shop';                 // SMTP username
        $mail->Password   = '14Sn*X;UF.0j';                         // SMTP password
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_SMTPS;            // Enable TLS encryption; `PHPMailer::ENCRYPTION_SMTPS` encouraged
        $mail->Port       = 465;                                    // TCP port to connect to, use 465 for `PHPMailer::ENCRYPTION_SMTPS` above
    
        //Recipients
        $mail->setFrom('envio@farmacias-cytotec-peru.shop', 'farmacias-cytotec-peru.shop');
        $mail->addAddress('contacto@farmacias-cytotec-peru.shop', 'Recibir Correo');    // Add a recipient   
    
        // Attachments
        // $mail->addAttachment('/var/tmp/file.tar.gz');            // Add attachments
        // $mail->addAttachment('/tmp/image.jpg', 'new.jpg');       // Optional name 
        
        
        $template  = "<table>";
        $template .= "<tr><td style='border-bottom: 1px solid; padding: 1rem;'><Strong>Nombre</Strong></td> <td style='border-bottom: 1px solid; padding: 1rem;'>$nombre</td> </tr>";
        $template .= "<tr><td style='border-bottom: 1px solid; padding: 1rem;'><Strong>Ciudad</Strong></td> <td style='border-bottom: 1px solid; padding: 1rem;'>$ciudad</td> </tr>";
        $template .= "<tr><td style='border-bottom: 1px solid; padding: 1rem;'><Strong>Celular</Strong></td> <td style='border-bottom: 1px solid; padding: 1rem;'>$telf</td> </tr>";
        $template .= "<tr><td style='border-bottom: 1px solid; padding: 1rem;'><Strong>Mensaje</Strong></td> <td style='border-bottom: 1px solid; padding: 1rem;'>$mensaje_usuario</td> </tr>";
        $template .= "</table>";
    
    
        // Content
        $mail->isHTML(true);                                  // Set email format to HTML
        $mail->Subject = 'Correo Desde - farmacias-cytotec-peru.shop - ' . date('d/m/y h:i:s A');
        $mail->Body    = $template;
        $mail->AltBody = "Nombre: $nombre;Ciudad: $ciudad;Celular: $telf;Mensaje: $mensaje_usuario";
    
        $mail->send();
        include 'sus-datos-exito.html';
    } catch (Exception $e) {
        include 'sus-datos-fallido.html';
    }

} else {
    include 'sus-datos-fallido.html';
}