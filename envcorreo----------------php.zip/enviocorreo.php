<?	
    $email_principal 	= 'rosamedrano90@outlook.es';
	$email_secundarios 	= 'bmw_7373@hotmail.com';
	$eol="\r\n";
	
	$cuerpo = "Mensaje desde la web www.farmacias-cytotec-peru.shop". "<br /><br />";
	$cuerpo .= "Nombre: " . $_POST["Nombre"] . "<br />"; 
	$cuerpo .= "Correo: " . $_POST["Correo"] . "<br />";
	$cuerpo .= "Distrito: " . $_POST["Distrito"] . "<br />";
	$cuerpo .= "Whats: " . $_POST["Whats"] . "<br />";
	$cuerpo .= "Consulta: " . $_POST["Consulta"] . "<br />";
		
	$headers .= 'From: '.utf8_decode($_POST['Nombre']).'<'.utf8_decode($_POST['Email']).'>'.$eol;
	$headers .= "CC: ".$email_secundarios.$eol;
	$headers .= "Reply-To: ".$mail."".$eol;
	$headers .= "Return-Path: ".$mail."".$eol;
	$headers .= "Message-ID: <".time()."-".$para.">".$eol;
	$headers .= "X-Mailer: PHP v".phpversion().$eol;
	$headers .= "MIME-Version: 1.0".$eol;
	$headers .= "Content-type: text/html; charset=iso-UTF-8;".$eol.$eol;
		
    mail($email_principal,"Mensaje recibido desde la pagina web www.farmacias-cytotec-peru.shop",$cuerpo,$headers);
	echo '<meta http-equiv="refresh" content="4;URL=http://www.farmacias-cytotec-peru.shop" />';
?>

<!DOCTYPE html>
<html dir="ltr" lang="es">
<head>

<!-- Meta Tags -->
<meta name="viewport" content="width=device-width,initial-scale=1.0"/>
<meta http-equiv="content-type" content="text/html; charset=UTF-8"/>
    <meta name="description" itemprop="description" content="Esta pagina Brinda Información sobre que es Cytotec misopostrol de 200mg, para que sirve, cómo funciona, qué efectos tiene, se brinda las indicaciones a seguir para tener un aborto seguro y eficaz. Asesoría y venta en Lima y otras ciudades de Perú" />
<meta name="keywords" itemprop="keywords" content="cytotec, cytotec lima, cytotec perú, vendo cytotec en lima, que es cytotec para que sirve, citotec, donde compro cytotec en lima, sitotec, misoprostol, misoprostol en lima, donde compro misoprostol peru, quiero misopostrol cytotec, cytotec misoprostol peru, misopostrol en cytotec lima peru, cytotec compra, cytotec precio, quiero comprar cytotec, cytotec en farmacias" />
	<meta name="robots" content="index" />
    <meta http-equiv="Content-Language" content="es"/>
	<meta name="Distribution" content="global"/>
	<meta name="country" content="pe" />

<!-- Page Title -->
<title>Contacto - Venta de Cytotec en Lima</title>

<!-- Favicon and Touch Icons -->
<link href="favicon.ico" rel="shortcut icon" type="image/png">

<!-- Stylesheet -->
<link href="css/bootstrap.min.css" rel="stylesheet" type="text/css">
<link href="css/jquery-ui.min.css" rel="stylesheet" type="text/css">
<link href="css/animate.css" rel="stylesheet" type="text/css">
<link href="css/css-plugin-collections.css" rel="stylesheet"/>
<!-- CSS | menuzord megamenu skins -->
<link id="menuzord-menu-skins" href="css/menuzord-skins/menuzord-rounded-boxed.css" rel="stylesheet"/>
<!-- CSS | Main style file -->
<link href="css/style-main.css" rel="stylesheet" type="text/css">
<!-- CSS | Preloader Styles -->
<link href="css/preloader.css" rel="stylesheet" type="text/css">
<!-- CSS | Custom Margin Padding Collection -->
<link href="css/custom-bootstrap-margin-padding.css" rel="stylesheet" type="text/css">
<!-- CSS | Responsive media queries -->
<link href="css/responsive.css" rel="stylesheet" type="text/css">
<!-- CSS | Style css. This is the file where you can place your own custom css code. Just uncomment it and use it. -->
<!-- <link href="css/style.css" rel="stylesheet" type="text/css"> -->

<!-- CSS | Theme Color -->
<link href="css/colors/theme-skin-yellow.css" rel="stylesheet" type="text/css">

<!-- external javascripts -->
<script src="js/jquery-2.2.4.min.js"></script>
<script src="js/jquery-ui.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<!-- JS | jquery plugin collection for this theme -->
<script src="js/jquery-plugin-collection.js"></script>

<!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
<!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
<!--[if lt IE 9]>
  <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
  <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
<![endif]-->
</head>
<body class="">
<div id="wrapper" class="clearfix">
  <!-- Header -->
  <header id="header" class="header">
    <div class="header-top bg-blue-111 sm-text-center p-0">
      <div class="container">
        <div class="row">
          <div class="col-md-6">
            <div class="widget no-border m-0">
              <ul class="list-inline xs-text-center text-white mt-5">
                <li class="m-0 pl-10 pr-10"> <a href="#" class="text-white"><i class="fa fa-phone text-theme-colored"></i> Pedidos: 791-7816</a> </li>
                <li class="m-0 pl-10 pr-10"> <i class="fa fa-clock-o text-theme-colored"></i> Atención: Lun a Dom 8:00 a 20:00 </li>
              </ul>
            </div>
          </div>
          <div class="col-md-4 pr-0">
            <div class="widget no-border m-0">
              <ul class="styled-icons icon-flat icon-sm pull-right flip sm-pull-none sm-text-center mt-sm-15">
                <li><a href="https://www.facebook.com/Cytoteconline-1638731879770988" target="_blank"> <i class="fa fa-facebook text-white"></i></a></li>
                <li><a href="https://twitter.com/CYTOTECenPERU" target="_blank"><i class="fa fa-twitter text-white"></i></a></li>
                <li><a href="https://plus.google.com/103486292107773890276" target="_blank"><i class="fa fa-google-plus text-white"></i></a></li>
              </ul>
            </div>
          </div>
          <div class="col-md-2">
            <a class="btn btn-colored btn-flat btn-theme-colored" href="contacto.html">Haz tus preguntas</a>
          </div>
        </div>
      </div>
    </div>
    <div class="header-nav">
      <div class="header-nav-wrapper navbar-scrolltofixed bg-white">
        <div class="container">
          <nav id="menuzord-right" class="menuzord">
            <a class="menuzord-brand pull-left flip" href="index.html">
              <img src="imagenes/aborto-seguro.png" alt="aborto-seguro">
            </a>
            <ul class="menuzord-menu">
              <li><a href="index.html">Inicio</a></li>
              <li><a href="que-es-cytotec.html">Que es Cytotec?</a></li>
              <li><a href="como-se-usa.html">Como se Usa?</a></li>
              <li><a href="lugares-de-venta.html">Lugares de Venta</a></li>
              <li class="active"><a href="contacto.html">Contacto</a></li>
            </ul>
          </nav>
        </div>
      </div>
    </div>
  </header>
  
  <!-- Start main-content -->
  <div class="main-content">
  <!-- Divider: Contact -->
    <section class="divider bg-lighter">
      <div class="container">
        <div class="row pt-30">
          <div class="col-md-7">
            <h3 class="line-bottom mt-0 mb-30">Consulta enviada con éxito!</h3>
           Gracias por escribir en breve nos pondremos en contacto.
		   <hr>
            <!-- Contact Form -->
            <form id="main-contact-form" class="contact-form" name="contact-form" method="post" action="enviocorreo.php">
              <div class="row">
                <div class="col-sm-6">
                  <div class="form-group">
                    <label>Tu Nombre <small>*</small></label>
                    <input name="Nombre" id="Nombre" class="form-control" type="text" required placeholder="Tu Nombre" >
                  </div>
                </div>
                <div class="col-sm-6">
                  <div class="form-group">
                    <label>Tu WhatsApp <small>*</small></label>
                    <input name="WhatsApp" id="WhatsApp" class="form-control" type="text" required placeholder="Tu WhatsApp">
                  </div>
                </div>
              </div>
              <div class="row">
                <div class="col-sm-6">
                  <div class="form-group">
                    <label>Cuál es tu distrito? <small>*</small></label>
                    <input name="Distrito" id="Distrito" class="form-control" type="text"  required placeholder="Tu Distrito">
                  </div>
                </div>
                <div class="col-sm-6">
                  <div class="form-group">
                    <label>Que edad tienes?</label>
                    <input name="Edad" id="Edad" class="form-control" type="text" required placeholder="Tu Edad">
                  </div>
                </div>
              </div>
              <div class="form-group">
                <label>Consulta</label>
                <textarea name="Consulta" id="Consulta" class="form-control" rows="5"  required placeholder="Ingresa tu Consulta"></textarea>
              </div>
              <div class="form-group">
                <input name="form_botcheck" class="form-control" type="hidden" value="" />
                <button class="btn-upper btn btn-primary checkout-page-button" name="Submit" type="submit" id="Submit"  value=" Enviar" /> Enviar Mensaje </button>
              </div>
            </form>
			 <!-- Contact Form Validation-->
            <br>
                   Es muy importante saber que aunque sea sencillo realizarse un aborto con 
				   medicamentos, la dosis debe ser la adecuada. Nosotros te vendemos Cytotec 
				   sin receta puedes conseguirlo en - <em> Cytotec cercado de Lima av. Nicolas Arriola</em>  
				   - <em>Vendemos cytotec en Lima cercado </em>

          </div>
          <div class="col-md-5">

            <!-- Google Map HTML Codes -->
            <div> <iframe src="https://www.google.com/maps/d/embed?mid=1xyJvI-C7A8xWN22N5wBAVrfKlws" 
					width="100%" height="650"></iframe> 
            </div>
            <!-- Google Map Javascript Codes -->
            <script src="http://maps.google.com/maps/api/js?key=AIzaSyAYWE4mHmR9GyPsHSOVZrSCOOljk8DU9B4"></script>
            <script src="js/google-map-init-multilocation.js"></script>
            
          </div>
        </div>
      </div>
    </section>
  </div>
  <!-- end main-content -->

  <!-- Footer -->
  <footer id="footer">
    
    <div class="footer-bottom bg-black-333">
      <div class="container pt-20 pb-20">
        <div class="row">
          <div class="col-md-6">
           
          </div>
          <div class="col-md-6 text-right flip">
            <div class="widget no-border m-0">
              <p class="font-11 text-black-777 m-0">Copyright &copy;2018 Cytotec. Derechos Reservados</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  </footer>
  <a class="scrollToTop" href="#"><i class="fa fa-angle-up"></i></a>
</div>
<!-- end wrapper -->
<!--Whatsapp-->
<div class="boton-whatsapp">
    <a href="https://api.whatsapp.com/send?phone=51925914810&text=Hola,%20que%20tal?" target="_blank" rel="noreferrer">
        <img src="./images/whatsapp.png" alt="botón del whatsapp">
    </a>
</div>
<!--Whatsapp-->
<!-- Footer Scripts -->
<!-- JS | Custom script for all pages -->
<script src="js/custom.js"></script>

</body>
</html>