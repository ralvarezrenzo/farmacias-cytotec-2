<?php 
session_start();

$nombre = $_POST['nombre'];
$apellidos = $_POST['apellidos'];
$celular = $_POST['celular'];
$correo = $_POST['correo'];
$ciudad = $_POST['ciudad'];
$comentario = $_POST['comentario'];


$remitente='cytoteconline';

$header = 'From: ' . $remitente . " \r\n";
$header .= "X-Mailer: PHP/" . phpversion() . " \r\n";
$header .= "Mime-Version: 1.0 \r\n";
$header .= "Content-Type: text/html";

$mensaje = "Este mensaje fue enviado por:" . $nombre . " ".$apellidos." <br>";
$mensaje .= "<b>Celular</b>: " . $celular . " <br>";
$mensaje .= "<b>Correo</b>: " . $correo . " <br>";
$mensaje .= "<b>Ciudad</b>: " . $ciudad . " <br>";
$mensaje .= "<b>Consulta</b>: " . $_POST['comentario'] . " <br>";
$mensaje .= "<b>Enviado el </b>" . date('d/m/Y', time());

$para = "rosamedrano90@outlook.es";
$asunto = 'Contacto desde la Web Farmacias';

mail($para, $asunto, utf8_decode($mensaje), $header);

header('location:contactomensaje.html');

$SESSION['exito']=TRUE;


?>